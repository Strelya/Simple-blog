-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 25 2018 г., 18:02
-- Версия сервера: 5.7.23
-- Версия PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `db`
--

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

CREATE TABLE `posts` (
  `post_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`post_id`, `name`, `description`, `text`) VALUES
(1, 'fdfdfdfdfd', 'fdfdfdfddfdf', 'fdfdfdfd'),
(2, 'fdfdfdfd', 'fdfdfdddddddddddddd', 'fdwweewewewewew'),
(3, 'fdfdfdfdfd1', 'fdfdfdfddfdf1', 'fdfdfdfd1'),
(4, 'fdfdfdfd1', 'fdfdfdddddddddddddd1', 'fdwweewewewewew1'),
(5, 'fdfdfdfdfd2', 'fdfdfdfddfdf2', 'fdfdfdfd2'),
(6, 'fdfdfdfd2', 'fdfdfdddddddddddddd2', 'fdwweewewewewew2'),
(7, 'fdfdfdfdfd12', 'fdfdfdfddfdf12', 'fdfdfdfd12'),
(8, 'fdfdfdfd12', 'fdfdfdddddddddddddd12', 'fdwweewewewewew12'),
(9, 'fdfdfdfdfd', 'fdfdfdfddfdf', 'fdfdfdfd'),
(10, 'fdfdfdfd', 'fdfdfdddddddddddddd', 'fdwweewewewewew'),
(11, 'fdfdfdfdfd1', 'fdfdfdfddfdf1', 'fdfdfdfd1'),
(12, 'fdfdfdfd1', 'fdfdfdddddddddddddd1', 'fdwweewewewewew1'),
(13, 'fdfdfdfdfd2', 'fdfdfdfddfdf2', 'fdfdfdfd2'),
(14, 'fdfdfdfd2', 'fdfdfdddddddddddddd2', 'fdwweewewewewew2'),
(15, 'fdfdfdfdfd12', 'fdfdfdfddfdf12', 'fdfdfdfd12'),
(16, 'fdfdfdfd12', 'fdfdfdddddddddddddd12', 'fdwweewewewewew12'),
(17, 'fdfdfdfdfd', 'fdfdfdfddfdf', 'fdfdfdfd'),
(18, 'fdfdfdfd', 'fdfdfdddddddddddddd', 'fdwweewewewewew'),
(19, 'fdfdfdfdfd1', 'fdfdfdfddfdf1', 'fdfdfdfd1'),
(20, 'fdfdfdfd1', 'fdfdfdddddddddddddd1', 'fdwweewewewewew1'),
(21, 'fdfdfdfdfd2', 'fdfdfdfddfdf2', 'fdfdfdfd2'),
(22, 'fdfdfdfd2', 'fdfdfdddddddddddddd2', 'fdwweewewewewew2'),
(23, 'fdfdfdfdfd12', 'fdfdfdfddfdf12', 'fdfdfdfd12'),
(24, 'fdfdfdfd12', 'fdfdfdddddddddddddd12', 'fdwweewewewewew12'),
(25, 'fdfdfdfdfd', 'fdfdfdfddfdf', 'fdfdfdfd'),
(26, 'fdfdfdfd', 'fdfdfdddddddddddddd', 'fdwweewewewewew'),
(27, 'fdfdfdfdfd1', 'fdfdfdfddfdf1', 'fdfdfdfd1'),
(28, 'fdfdfdfd1', 'fdfdfdddddddddddddd1', 'fdwweewewewewew1'),
(29, 'fdfdfdfdfd2', 'fdfdfdfddfdf2', 'fdfdfdfd2'),
(30, 'fdfdfdfd2', 'fdfdfdddddddddddddd2', 'fdwweewewewewew2'),
(31, 'fdfdfdfdfd12', 'fdfdfdfddfdf12', 'fdfdfdfd12'),
(32, 'fdfdfdfd12', 'fdfdfdddddddddddddd12', 'fdwweewewewewew12');

-- --------------------------------------------------------

--
-- Структура таблицы `terms`
--

CREATE TABLE `terms` (
  `terms_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `descr` varchar(255) NOT NULL,
  `type` enum('tag','category') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `terms`
--

INSERT INTO `terms` (`terms_id`, `title`, `text`, `descr`, `type`) VALUES
(1, 'Отзывы', 'Перечень отзывов от розничных клиентов', '', 'category'),
(2, 'Отзывы партнеров', 'Отзывы от наших партнеров', '', 'category'),
(3, 'Положительные', 'Положительные отзывы', '', 'tag'),
(4, 'Отрицательные', 'Отрицательные отзывы', '', 'tag');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`);

--
-- Индексы таблицы `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`terms_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT для таблицы `terms`
--
ALTER TABLE `terms`
  MODIFY `terms_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

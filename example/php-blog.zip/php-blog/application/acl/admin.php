<?php

return [
	'all' => [
		'login',
	],
	'authorize' => [
		//
	],
	'guest' => [
		//
	],
	'admin' => [
		'posts',
		'logout',
		'add',
		'edit',
		'delete',
	],
];
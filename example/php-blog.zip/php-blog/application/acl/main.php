<?php

return [
	'all' => [
		'index',
		'about',
		'contact',
		'post',
	],
	'authorize' => [
		//
	],
	'guest' => [
		//
	],
	'admin' => [
		//
	],
];
<?php

return [
	'host' => '127.0.0.1',
	'name' => 'db',
	'user' => 'user',
	'password' => 'pass',
];
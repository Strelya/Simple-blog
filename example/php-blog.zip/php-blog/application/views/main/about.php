<header class="masthead" style="background-image: url('/public/images/about-bg.jpg')">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-10 mx-auto">
                <div class="page-heading">
                    <h1>Я программист</h1>
                    <span class="subheading">записываю бесплатные обучающие видео по PHP</span>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="container">
    <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
            <p>Здесь могло быть больше текста, но мне лень писать :)</p>
        </div>
    </div>
</div>